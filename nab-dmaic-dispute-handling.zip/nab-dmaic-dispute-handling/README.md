# NAB DMAIC — Transaction Dispute Handling (Sample)

> **Demo / training sample only.** Inspired by public reporting on NAB conversational AI data tools. Not official NAB documentation. Metrics and case data are **illustrative**.

## Problem in one line
Customers chase dispute status by phone because of a visibility gap — not because investigations are inherently slow.

## Goal
- Reduce repeat customer phone calls by **30%**
- Improve transparency across the dispute resolution lifecycle

## Scope
Inbound customer transaction dispute workflows handled by support and operations teams.

## DMAIC map

| Phase | Folder | Focus |
|-------|--------|--------|
| **D**efine | [`docs/01-define/`](docs/01-define/) | Problem, charter, VOC |
| **M**easure | [`docs/02-measure/`](docs/02-measure/) | TAT, follow-up calls, baseline |
| **A**nalyze | [`docs/03-analyze/`](docs/03-analyze/) | Black-hole gap, root cause |
| **I**mprove | [`docs/04-improve/`](docs/04-improve/) | Event-driven AI status updates |
| **C**ontrol | [`docs/05-control/`](docs/05-control/) | Monthly KPIs + SOP triggers |

## Sample data
[`data/sample_baseline_disputes.csv`](data/sample_baseline_disputes.csv) — fictional baseline rows (AUD banking flavour).

## Baseline highlight (illustrative)
Customers call an average of **1.4 times** post-submission due to lack of visibility (docs received / under review / resolved).

## Solution sketch
Integrate conversational AI data capabilities (Customer Brain / Genie-style) to auto-trigger proactive status updates at milestones: info needed, under review, finalized.

## Reference (public)
[BrokerNews — NAB conversational AI data tool](https://www.brokernews.com.au/news/breaking-news/nab-breaks-new-ground-with-conversational-ai-data-tool-289542.aspx)

## License
See [LICENSE](LICENSE). Sample materials; no claim of NAB endorsement.
